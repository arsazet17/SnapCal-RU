package com.ghostwan.snapcal.data.remote

import android.util.Base64
import com.ghostwan.snapcal.domain.model.UserProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class GeminiApiService {

    companion object {
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"
        private const val MAX_RETRIES = 3
        private val RETRY_DELAYS_MS = longArrayOf(2_000, 5_000, 10_000)

        val AVAILABLE_MODELS = listOf(
            "gemini-2.5-flash",
            "gemini-2.5-pro",
            "gemini-2.5-flash-lite"
        )
    }

    var model: String = AVAILABLE_MODELS.first()

    suspend fun analyzeImage(imageData: ByteArray, apiKey: String, language: String): String {
        val base64Image = Base64.encodeToString(imageData, Base64.NO_WRAP)
        val requestBody = buildImageRequestBody(buildAnalysisPrompt(language), base64Image)
        return executeRequest(requestBody, apiKey)
    }

    suspend fun analyzeText(description: String, apiKey: String, language: String): String {
        val prompt = """
            A user describes what they ate:
            "$description"

            Based on this description, provide a detailed nutritional estimation.
            IMPORTANT: All text values in your response (dish name, ingredient names, notes, quantities) MUST be written in $language.

            Estimate the edible weight of EVERY ingredient in grams. Quantity must be a single positive number followed by the Russian unit г, e.g. 150 г. All macro values use г. Nutrition values refer to the listed amounts, not to 100 grams. The totalCalories must equal the sum of ingredient calories.

            Respond ONLY with valid JSON (no markdown, no backticks) in this exact format:
            {
                "emoji": "🍝",
                "dishName": "Название блюда",
                "totalCalories": 500,
                "ingredients": [
                    {"name": "Продукт 1", "quantity": "150 г", "calories": 200, "healthRating": "healthy"},
                    {"name": "Продукт 2", "quantity": "30 г", "calories": 100, "healthRating": "moderate"}
                ],
                "macros": {
                    "proteins": "25 г",
                    "carbs": "60 г",
                    "fats": "15 г",
                    "fiber": "5 г"
                },
                "notes": "Оценка приблизительная"
            }

            The "emoji" field must be a single emoji that best represents the dish (e.g. 🍕 for pizza, 🥗 for salad, 🍣 for sushi).
            The "healthRating" field for each ingredient must be "healthy" (nutritious, whole foods), "moderate" (acceptable in moderation), or "unhealthy" (highly processed, high sugar/fat).
        """.trimIndent()

        return executeRequest(buildTextRequestBody(prompt), apiKey)
    }

    suspend fun correctAnalysis(
        originalAnalysisJson: String,
        userFeedback: String,
        imageData: ByteArray?,
        apiKey: String,
        language: String
    ): String {
        val prompt = """
            You previously analyzed a food photo and gave this result:
            $originalAnalysisJson

            The user says this is incorrect and provides this feedback:
            "$userFeedback"

            Please re-analyze and provide a corrected estimation based on the user's feedback.
            IMPORTANT: All text values in your response MUST be written in $language. Quantity must be edible weight in grams, e.g. 150 г. Recalculate all calories and macros for the corrected products and weights. totalCalories must equal the sum of ingredient calories.

            Respond ONLY with valid JSON (no markdown, no backticks) in this exact format:
            {
                "emoji": "🍝",
                "dishName": "Название блюда",
                "totalCalories": 500,
                "ingredients": [
                    {"name": "Продукт 1", "quantity": "150 г", "calories": 200, "healthRating": "healthy"}
                ],
                "macros": {
                    "proteins": "25 г",
                    "carbs": "60 г",
                    "fats": "15 г",
                    "fiber": "5 г"
                },
                "notes": "Оценка приблизительная"
            }

            The "emoji" field must be a single emoji that best represents the dish.
            The "healthRating" field for each ingredient must be "healthy" (nutritious, whole foods), "moderate" (acceptable in moderation), or "unhealthy" (highly processed, high sugar/fat).
        """.trimIndent()

        val requestBody = if (imageData != null) {
            val base64Image = Base64.encodeToString(imageData, Base64.NO_WRAP)
            buildImageRequestBody(prompt, base64Image)
        } else {
            buildTextRequestBody(prompt)
        }
        return executeRequest(requestBody, apiKey)
    }

    suspend fun pickEmoji(productName: String, apiKey: String): String {
        val prompt = "Reply with a single emoji that best represents this food product: \"$productName\". Reply ONLY with the emoji, nothing else."
        val rawResponse = executeRequest(buildTextRequestBody(prompt), apiKey)
        val text = JSONObject(rawResponse)
            .getJSONArray("candidates")
            .getJSONObject(0)
            .getJSONObject("content")
            .getJSONArray("parts")
            .getJSONObject(0)
            .getString("text")
            .trim()
        // Extract first emoji (could have trailing whitespace/text)
        val emojiRegex = Regex("[\\p{So}\\p{Cs}]+")
        return emojiRegex.find(text)?.value ?: "🍽️"
    }

    suspend fun generateWeeklyReport(
        dailySummaries: String,
        profile: UserProfile,
        goal: String,
        apiKey: String,
        language: String
    ): String {
        val prompt = """
            You are a nutrition coach. Analyze this user's weekly nutrition data and provide a helpful summary.

            User profile:
            - Height: ${profile.height} cm, Weight: ${profile.weight} kg, Target: ${profile.targetWeight} kg
            - Gender: ${profile.gender.name.lowercase()}, Activity: ${profile.activityLevel.name.lowercase().replace("_", " ")}

            Daily goals: $goal

            Daily nutrition data for the past week:
            $dailySummaries

            IMPORTANT: Write everything in $language.

            Respond ONLY with valid JSON (no markdown, no backticks) in this exact format:
            {
                "summary": "Brief overview of the week (2-3 sentences)",
                "avgCalories": 1800,
                "avgProteins": 90,
                "avgCarbs": 200,
                "avgFats": 60,
                "strengths": ["Strength 1", "Strength 2"],
                "improvements": ["Area to improve 1", "Area to improve 2"],
                "tip": "One practical tip for next week"
            }
        """.trimIndent()

        return executeRequest(buildTextRequestBody(prompt), apiKey)
    }

    suspend fun suggestMeals(
        profile: UserProfile,
        remainingCalories: Int,
        remainingProteins: Float,
        remainingCarbs: Float,
        remainingFats: Float,
        mealType: String,
        recentDishes: List<String>,
        apiKey: String,
        language: String
    ): String {
        val recentList = if (recentDishes.isNotEmpty()) {
            "\nRecent dishes the user has eaten (for variety, suggest different things): ${recentDishes.joinToString(", ")}"
        } else ""

        val prompt = """
            You are a nutrition advisor. A user needs meal suggestions for their next $mealType.

            User profile:
            - Height: ${profile.height} cm
            - Weight: ${profile.weight} kg
            - Target weight: ${profile.targetWeight} kg
            - Gender: ${profile.gender.name.lowercase()}
            - Activity level: ${profile.activityLevel.name.lowercase().replace("_", " ")}

            Remaining daily budget:
            - Calories: $remainingCalories kcal
            - Proteins: ${remainingProteins.toInt()}g
            - Carbs: ${remainingCarbs.toInt()}g
            - Fats: ${remainingFats.toInt()}g
            $recentList

            Suggest exactly 3 meal options that fit within the remaining budget.
            IMPORTANT: All text MUST be in $language.

            Respond ONLY with valid JSON (no markdown, no backticks) in this exact format:
            {
                "suggestions": [
                    {
                        "emoji": "🥗",
                        "dishName": "Dish name",
                        "estimatedCalories": 400,
                        "proteins": "30g",
                        "carbs": "40g",
                        "fats": "12g",
                        "description": "Brief description of why this is a good choice"
                    }
                ]
            }
        """.trimIndent()

        return executeRequest(buildTextRequestBody(prompt), apiKey)
    }

    suspend fun computeNutritionGoal(profile: UserProfile, apiKey: String, language: String): String {
        val prompt = """
            Given a person with the following characteristics:
            - Height: ${profile.height} cm
            - Weight: ${profile.weight} kg
            - Target weight: ${profile.targetWeight} kg
            - Age: ${profile.age}
            - Gender: ${profile.gender.name.lowercase()}
            - Activity level: ${profile.activityLevel.name.lowercase().replace("_", " ")}

            Calculate recommended daily nutritional goals to help them reach their target weight in a healthy way.
            IMPORTANT: Write the explanation in $language.

            Respond ONLY with valid JSON (no markdown, no backticks) in this exact format:
            {
                "calories": 2000,
                "proteins_g": 120.0,
                "carbs_g": 200.0,
                "fats_g": 65.0,
                "fiber_g": 30.0,
                "explanation": "Brief explanation of the recommendation"
            }
        """.trimIndent()

        return executeRequest(buildTextRequestBody(prompt), apiKey)
    }

    private suspend fun executeRequest(requestBody: String, apiKey: String): String {
        return withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) throw GeminiApiException("Не указан API-ключ Gemini. Откройте настройки на экране добавления еды.")
            val selectedModel = model.takeIf { it in AVAILABLE_MODELS } ?: AVAILABLE_MODELS.first()
            for (attempt in 0..MAX_RETRIES) {
                if (attempt > 0) kotlinx.coroutines.delay(RETRY_DELAYS_MS[attempt - 1])
                val connection = URL("$BASE_URL/$selectedModel:generateContent").openConnection() as HttpURLConnection
                try {
                    connection.requestMethod = "POST"
                    connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    connection.setRequestProperty("x-goog-api-key", apiKey)
                    connection.instanceFollowRedirects = false
                    connection.doOutput = true
                    connection.connectTimeout = 30_000
                    connection.readTimeout = 60_000
                    connection.outputStream.use { it.write(requestBody.toByteArray(Charsets.UTF_8)) }
                    val code = connection.responseCode
                    if (code == 200) return@withContext connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    if ((code == 429 || code in 500..599) && attempt < MAX_RETRIES) continue
                    val message = when (code) {
                        400 -> "Gemini отклонил запрос. Проверьте API-ключ, фотографию и описание блюда."
                        401, 403 -> "Gemini отклонил доступ. Проверьте API-ключ, права и доступность сервиса для вашего аккаунта."
                        404 -> "Эта модель Gemini недоступна. Выберите другую модель в настройках."
                        429 -> "Квота Gemini исчерпана. Повторите позже или проверьте лимиты своего ключа в Google AI Studio."
                        in 500..599 -> "Сервис Gemini временно недоступен. Повторите попытку позже."
                        else -> "Не удалось выполнить запрос к Gemini (код $code)."
                    }
                    throw GeminiApiException(message)
                } finally {
                    connection.disconnect()
                }
            }
            throw GeminiApiException("Не удалось получить ответ Gemini после повторных попыток.")
        }
    }

    private fun buildTextRequestBody(prompt: String): String {
        return JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", prompt) })
                    })
                })
            })
        }.toString()
    }

    private fun buildImageRequestBody(prompt: String, base64Image: String): String {
        return JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", prompt) })
                        put(JSONObject().apply {
                            put("inlineData", JSONObject().apply {
                                put("mimeType", "image/jpeg")
                                put("data", base64Image)
                            })
                        })
                    })
                })
            })
        }.toString()
    }

    private fun buildAnalysisPrompt(language: String): String {
        return """
            Analyze this food photo and provide a detailed estimation.
            IMPORTANT: All text values in your response (dish name, ingredient names, notes, quantities) MUST be written in $language.

            Estimate the edible weight of EVERY ingredient in grams. Quantity must be a single positive number followed by the Russian unit г, e.g. 150 г. All macro values use г. Nutrition values refer to the listed amounts, not to 100 grams. The totalCalories must equal the sum of ingredient calories.

            Respond ONLY with valid JSON (no markdown, no backticks) in this exact format:
            {
                "emoji": "🍝",
                "dishName": "Название блюда",
                "totalCalories": 500,
                "ingredients": [
                    {"name": "Продукт 1", "quantity": "150 г", "calories": 200, "healthRating": "healthy"},
                    {"name": "Продукт 2", "quantity": "30 г", "calories": 100, "healthRating": "moderate"}
                ],
                "macros": {
                    "proteins": "25 г",
                    "carbs": "60 г",
                    "fats": "15 г",
                    "fiber": "5 г"
                },
                "notes": "Оценка приблизительная"
            }

            The "emoji" field must be a single emoji that best represents the dish (e.g. 🍕 for pizza, 🥗 for salad, 🍣 for sushi).
            The "healthRating" field for each ingredient must be "healthy" (nutritious, whole foods), "moderate" (acceptable in moderation), or "unhealthy" (highly processed, high sugar/fat).

            If the image does not contain food, respond with:
            {"emoji": "❓", "dishName": "Еда не распознана", "totalCalories": 0, "ingredients": [], "macros": null, "notes": "На фотографии не удалось распознать еду."}
        """.trimIndent()
    }
}

class GeminiApiException(message: String) : Exception(message)
